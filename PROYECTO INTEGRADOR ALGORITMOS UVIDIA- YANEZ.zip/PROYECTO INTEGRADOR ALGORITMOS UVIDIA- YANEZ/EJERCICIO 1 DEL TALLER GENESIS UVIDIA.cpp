// PROYECTO INTEGRADOR UVIDIA- YANEZ

//librer�as
#include <iostream>

using namespace std; 

//entrada 
int main() {
	// definir variables
    const int empresas = 5;
    float cotizacion[empresas];
    
    // proceso
    
	// Ingreso de las cotizaciones
    std::cout << "Ingrese el monto de la cotizacion:\n";
    for (int i = 0; i < empresas; ++i) {
        std::cout << "Cotizacion empresa " << i + 1 << ": ";
        std::cin >> cotizacion[i];
    }

    // Esta parte inicia la diferenciaci�n de la cotizaci�n m�s alta vs la m�s baja
    int cotizacionmin = 0;
    int cotizacionmax = 0;

    for (int i = 1; i < empresas; ++i) {
                    if (cotizacion[i] > cotizacion[cotizacionmax]) {
            cotizacionmax = i;
        }

        if (cotizacion[i] < cotizacion[cotizacionmin]) {
            cotizacionmin = i;
        }
    }

    // Mostrar cotizaciones eliminadas- salida
    std::cout << "\nCotizaciones eliminadas:\n";
    std::cout << "La cotizaci�n mas alta es: " << cotizacion[cotizacionmax] << std::endl;
    std::cout << "La cotizaci�n mas baja es: " << cotizacion[cotizacionmin] << std::endl;

    // Para las cotizaciones restantes
    float sumacot = 0;
    int contador = 0;

    for (int i = 0; i < empresas; ++i) {
        if (i != cotizacionmin && i != cotizacionmax) {
            sumacot += cotizacion[i];
            contador++;
        }
    }

    float promediocot = sumacot / contador;
//salida
    std::cout << "\nEl promedio de las cotizaciones restantes es: " << promediocot << std::endl;

    return 0;
}
