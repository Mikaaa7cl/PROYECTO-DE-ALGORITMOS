#include <iostream>
using namespace std; 
int main() {
    const int empresas = 5;
    float cotizacion[empresas];

    // Ingreso de las cotizaciones
    std::cout << "Ingrese el monto de la cotizacion:\n";
    for (int i = 0; i < empresas; ++i) {
        cout << "Cotizacion empresa " << i + 1 << ": ";
        cin >> cotizacion[i];
    }

    // Esta parte inicia la diferenciaci�n de la cotizaci�n m�s alta vs la m�s baja
    int cotizacionmin = 0;
    int cotizacionmax = 0;

    for (int i = 1; i < empresas; ++i) {
                    if (cotizacion[i] > cotizacion[cotizacionmax]) {
            cotizacionmax = i;
        }

        if (cotizacion[i] < cotizacion[cotizacionmin]) {
            cotizacionmin = i;
        }
    }

    // Mostrar cotizaciones eliminadas
    cout << "\nCotizaciones eliminadas:\n";
    cout << "La cotizaci�n mas alta es: " << cotizacion[cotizacionmax] << endl;
    cout << "La cotizaci�n mas baja es: " << cotizacion[cotizacionmin] << endl;

    // Para las cotizaciones restantes
    float sumacot = 0;
    int contador = 0;

    for (int i = 0; i < empresas; ++i) {
        if (i != cotizacionmin && i != cotizacionmax) {
            sumacot += cotizacion[i];
            contador++;
        }
    }

    float promediocot = sumacot / contador;

    cout << "\nEl promedio de las cotizaciones restantes es: " << promediocot << endl;

}
